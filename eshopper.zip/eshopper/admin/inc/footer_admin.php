
<footer id="footer"><!--Footer-->

    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <p class="pull-left">Copyright © 2019 E-ARIARY Inc. All rights reserved.</p>
            </div>
        </div>
    </div>

</footer><!--/Footer-->

<script src="<?= BASE_NAME; ?>js/jquery.js"></script>
<script src="<?= BASE_NAME; ?>js/bootstrap.min.js"></script>
<script src="<?= BASE_NAME; ?>js/jquery.scrollUp.min.js"></script>
<script src="<?= BASE_NAME; ?>js/price-range.js"></script>
<script src="<?= BASE_NAME; ?>js/jquery.prettyPhoto.js"></script>
<script src="<?= BASE_NAME; ?>js/main.js"></script>
</body>

</html>