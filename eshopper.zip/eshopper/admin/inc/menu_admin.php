<div class="col-sm-3">
    <div class="left-sidebar">
        <h2>Admin</h2>
        <div class="panel-group category-products" id="accordian"><!--category-productsr-->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title"><a href="../index.php">Aller sur le site</a></h4>
                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title"><a href="produit_list.php">Produits</a></h4>
                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title"><a href="categ_list.php">Categories</a></h4>
                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordian" href="#article">
                            <span class="badge pull-right"><i class="fa fa-angle-double-down"></i></span>
                            Articles
                        </a>
                    </h4>
                </div>
                <div id="article" class="panel-collapse collapse">
                    <div class="panel-body">
                        <ul>
                            <li><a href="#"><span class="fa fa-plus"> Ajouter nouveau article</span></a></li>
                            <li><a href="#"><span class="fa fa-list"> Liste des articles</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div><!--/category-productsr-->
    </div>
</div>