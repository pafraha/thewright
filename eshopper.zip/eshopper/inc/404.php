<?php require_once 'header.php'; ?>

<div class="container text-center">
    <div class="logo-404">
        <a href="../index.php"><img src="../images/home/logo.png" alt="" /></a>
    </div>
    <div class="content-404">
        <img src="../images/404/404.png" class="img-responsive" alt="" />
        <h1><b>OPPS!</b> Page introuvable.</h1>
        <p>Uh... Peut-être que vous avez tapé quelque chose qui n'existe pas..</p>
        <h2><a href="../index.php">&lArr; Retourne à l'accueil</a></h2>
    </div>
</div>


<?php require_once 'footer.php'; ?>
